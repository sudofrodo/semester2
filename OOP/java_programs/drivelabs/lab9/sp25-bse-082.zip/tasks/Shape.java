interface Shape{
    double area();
    
}